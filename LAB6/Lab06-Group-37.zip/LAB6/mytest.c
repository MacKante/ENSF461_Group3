#include "myalloc.c"

void main() {
int test=1;
  int size, size2, size3;
  int page_size = getpagesize();
  void *buff, *buff2, *buff3;
  node_t *header, *header2, *header3; 

  myinit(page_size);

  size=64;
  size2=128;
  //Have the third allocation fill up the rest of the arena
  size3=page_size - size - size2 - sizeof(node_t)*3;
  
  //Case 1: Combine prev, current, next
  buff = myalloc(size);
  buff2 = myalloc(size2);
  buff3 = myalloc(size3);
  
  header = ((void*)buff) - sizeof(node_t);
  header2 = ((void*)buff2) - sizeof(node_t);
  header3 = ((void*)buff3) - sizeof(node_t);

  myfree(buff); 
  printf("HEREEEEEEEEEEEEEEEEEEEEEEEEEEE1\n");
  myfree(buff3);
  printf("HERE2EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE2\n");  
  //this should cause coalescing. 
  myfree(buff2);
  printf("HERE3EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE\n");
  printf("expected %ld, got %ld\n", page_size - sizeof(node_t), header->size); 

}